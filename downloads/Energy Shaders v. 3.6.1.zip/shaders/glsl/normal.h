highp vec3 calculateSurfaceNormal(highp vec3 chunkedPos){
  //use opengl es build in function to fix precision issue.
  //also use chunkedPos here because it is much more exact
  return normalize(cross(dFdx(chunkedPos), dFdy(chunkedPos)));
}
