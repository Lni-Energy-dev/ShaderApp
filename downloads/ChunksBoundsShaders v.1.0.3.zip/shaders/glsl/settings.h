//[--]

//[title]Chunk-Line settings

#define CHUNK_LINE_WIDTH 0.25
//[-]
#define CHUNK_LINE_COLOR vec3(1.0, 0.0, 0.0)
