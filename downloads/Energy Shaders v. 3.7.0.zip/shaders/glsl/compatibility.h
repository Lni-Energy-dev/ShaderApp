
#ifndef COMPATIBILITY_H
  #define COMPATIBILITY_H
#endif

//#define vec2 vec2
//#define vec3 vec3
#define hvec3 highp vec3
//#define vec4 vec4
//#define mix mix

#define VEC2 vec2
#define VEC3 vec3
#define VEC4 vec4
